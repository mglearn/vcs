# Book Recommendation Gallery - Setup

A free, self-hosted alternative to commercial reading-promotion tools. Students submit book recommendations with a cover photo, title, author, genre, and a short "why other students should read this" review. The gallery shows all approved recommendations in a masonry grid, filterable by genre.

Built on Miguel Guhlin's ShareSpace, customized for K-12 library use.

Total setup time: about 15 minutes.

## What's in this folder

| File          | Purpose                                                                              |
| ------------- | ------------------------------------------------------------------------------------ |
| `code.gs`     | Google Apps Script backend (handles uploads and stores data in your Drive)           |
| `submit.html` | Student-facing submission form. Auto-redirects to the gallery after success.        |
| `board.html`  | Public gallery with genre filters and 60-second auto-refresh                         |
| `admin.html`  | Passcode-protected page for librarians to edit details, reviews, or delete entries  |

## What changed from the original ShareSpace

This version adds three new fields beyond the original ShareSpace:

- **bookTitle** (required) - the book being recommended
- **bookAuthor** (required) - the author
- **gradeLevel** (optional) - the recommender's grade (Pre-K through 12, or Staff)

The genre categories are also pre-set for a library context:

- Realistic Fiction
- Fantasy & Sci-Fi
- Mystery & Adventure
- Graphic Novel
- Nonfiction
- Biography & Memoir

The admin page now lets you edit any field, not just the review text. Useful when a student misspells a title or picks the wrong genre.

## Step 1 - Create the Apps Script project

1. Go to [script.google.com](https://script.google.com) and click **New project**.
2. Rename the project at the top left - for example, `Book Recommendation Gallery`.
3. Delete the placeholder code in `Code.gs` and paste in the contents of `code.gs` from this folder.
4. Save (Ctrl+S or Cmd+S).

## Step 2 - Run setupNow once

1. In the function dropdown at the top of the editor, select `setupNow`.
2. Click **Run**.
3. Authorize when prompted. If you see "Google hasn't verified this app," click **Advanced** > **Go to (project name) (unsafe)** > **Allow**. This is normal for personal Apps Script projects.
4. Verify in your Drive: a folder named `Book Recommendation Gallery` with a subfolder for each genre, plus a Google Sheet named `Book Recommendations Log`.

## Step 3 - Set the admin passcode

1. Click the gear icon on the left side of the editor (Project Settings).
2. Scroll to **Script Properties** > **Edit script properties** > **Add script property**.
3. Property: `ADMIN_PASSCODE`
4. Value: any passcode you choose. This is what you'll type into the admin page.
5. Save.

If you skip this step, the admin page will tell you the passcode isn't configured. Submissions and the public gallery still work.

## Step 4 - Deploy as a web app

1. Click **Deploy** > **New deployment**.
2. Click the gear next to "Select type" and choose **Web app**.
3. Fill in:
   - Description: a label like `v1`
   - Execute as: **Me (your.email@domain.com)**
   - Who has access: **Anyone**
4. Click **Deploy**.
5. Authorize again if asked.
6. Copy the **Web app URL** (ends in `/exec`).

**Important:** "Who has access: Anyone" is required. If you set it to "Only myself" or "Anyone with Google account", the form will not work for students.

## Step 5 - Health check the deployment

Paste your Web app URL into the browser address bar, and add `?action=ping` to the end. You should see a JSON response that looks roughly like:

```json
{"ok":true,"project":"Book Recommendation Gallery","categories":["Realistic Fiction",...],"passcodeSet":true,"time":"2026-..."}
```

If you see this, your backend is reachable and configured. If you see an HTML error page or "Sorry, the file you have requested does not exist," the deployment access isn't set to **Anyone** - go back to Step 4.

If `passcodeSet` is `false`, go back to Step 3.

## Step 6 - Wire the URL into the three HTML files

In `submit.html`, `board.html`, and `admin.html`, find this line near the top of the `<script>` block:

```javascript
const SCRIPT_URL = 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE';
```

Replace the placeholder with your Web app URL. Save all three files.

## Step 7 - Host the files

Keep `submit.html`, `board.html`, and `admin.html` together in the same folder. The post-submission redirect uses a relative link (`board.html`) and depends on this.

Hosting options:

- **GitHub Pages** - free, fast, works in five minutes
- **Your campus intranet** - if you have one
- **WordPress media library** - upload as a zip, embed via iframe
- **Any static host** - Netlify, Vercel, Cloudflare Pages

For WordPress embedding, use a Custom HTML block:

```html
<iframe src="https://yourdomain.com/path/to/gallery/submit.html"
        width="100%" height="1300" frameborder="0"
        style="border: none;"></iframe>
```

Suggested iframe heights:

- `submit.html`: 1300-1400 (it has more fields than the original)
- `board.html`: 1500-1800
- `admin.html`: full standalone page, not embedded

If you embed `submit.html` and want the redirect to take students to a different WordPress page hosting `board.html`, change `BOARD_URL` near the top of `submit.html`'s script block from `'board.html'` to the absolute URL.

## Step 8 - Test it end to end

1. Open `submit.html` in a private browser window (so you're not logged in as the librarian).
2. Submit a test recommendation with a real book - any cover image from your phone works.
3. Watch the success panel count down from 3 and redirect to the gallery.
4. Confirm your test entry shows: cover image, book title (large), author, recommender + grade, genre pill, and your "why" text.
5. Open `admin.html`. Enter your passcode.
6. Click **Edit details** on the test entry. Change the title. Save. Confirm the gallery shows the new title within 60 seconds.
7. Click **Edit review** on the same entry. Update the review. Save. Confirm it updates.
8. Click **Delete**. Confirm it's gone from the gallery.

## Updating code.gs later - important

If you change `code.gs` after deploying, you **must** redeploy as a new version, or the live URL keeps running the old code. This is the single most common reason "I edited Code.gs but nothing changed":

1. **Deploy** > **Manage deployments**
2. Click the **pencil icon** on your existing deployment
3. Under **Version**, choose **New version**
4. Click **Deploy**

The Web app URL stays the same. The HTML files keep working - no need to update them.

## Customizing further

**Different genres for your campus.** Edit `ALLOWED_CATEGORIES` in `code.gs` and the matching `CATEGORIES` arrays in `submit.html`, `board.html`, and `admin.html`. All four must match exactly.

**Different grade labels** (for example, middle school only). Edit `ALLOWED_GRADES` in `code.gs` and the matching grade options in `submit.html` and `admin.html`.

**Stricter file rules.** Want to require cover photos only? The submit page already restricts the file picker to images and PDFs via `accept="image/*,application/pdf"`. To enforce this server-side, add a MIME type check inside `submitNew()` in `code.gs`.

**Anonymous submissions.** If your library wants anonymous recommendations, remove the `name` and `email` fields from `submit.html`, and remove the corresponding validation in `submitNew()` in `code.gs`. The gallery will then show "Recommended by Anonymous."

**Limit who can submit.** This template intentionally has no submission authentication so students can submit from any device. If your campus requires sign-in, change the Apps Script deployment access from "Anyone" to "Anyone with Google account" and add a domain check inside `submitNew()`.

## Troubleshooting

| Symptom                                                              | Likely cause                                                                              |
| -------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| "Backend returned an unexpected response"                            | Deployment access not "Anyone", or you didn't redeploy after editing `code.gs`            |
| "Could not reach the backend"                                        | `SCRIPT_URL` typo, or no internet                                                         |
| "Please choose a genre from the list"                                | Category lists in the four files don't match exactly                                      |
| Admin says "Invalid passcode" even when typed right                  | `ADMIN_PASSCODE` not set in Script Properties, or trailing whitespace                     |
| Cover thumbnails don't show on the gallery                           | Workspace policy blocks public sharing - files fall back to domain-only and won't preview |
| Submission fails with no clear error                                 | Open browser devtools > Console tab to see the actual error text                          |

## Privacy notes

- Email addresses are captured for accountability but never shown on the public gallery. Only the admin page (passcode-protected) displays them.
- Files live in the librarian's Google Drive. When a recommendation is deleted from admin, the file moves to Drive trash, recoverable for 30 days.
- The submit and gallery pages have no authentication, by design. The admin page is passcode-protected. This is classroom-grade security.

---

*Customized from ShareSpace by Miguel Guhlin - [blog.tcea.org](https://blog.tcea.org) | Social: [mguhlin.org](https://mguhlin.org)*
