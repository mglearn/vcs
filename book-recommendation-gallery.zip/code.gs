/**
 * Book Recommendation Gallery - Google Apps Script Backend
 *
 * A student-driven book recommendation gallery. Students upload a book
 * cover (photo, scan, or hand-drawn), tag it with a genre, and write a
 * short "why other students should read this" note. The board displays
 * all approved recommendations as a masonry grid, filterable by genre.
 *
 * Built on Miguel Guhlin's ShareSpace - customized for K-12 library use.
 *
 * --------------------------------------------------------------------
 * QUICK START
 * --------------------------------------------------------------------
 *  1. Edit the CONFIG block below for your campus (PROJECT_NAME, etc.).
 *  2. Run setupNow() once from the editor (authorize when prompted).
 *  3. Project Settings (gear) > Script Properties > add ADMIN_PASSCODE.
 *  4. Deploy > New deployment > Web app, Execute as: Me, Access: Anyone.
 *  5. Paste the deployed Web app URL into submit.html, board.html,
 *     and admin.html (the SCRIPT_URL constant near the top of each).
 *
 * --------------------------------------------------------------------
 * UPDATING LATER
 * --------------------------------------------------------------------
 *  Deploy > Manage deployments > pencil icon > Version: New version
 *  > Deploy. The Web app URL stays the same.
 *
 * Original ShareSpace by Miguel Guhlin - blog.tcea.org | mguhlin.org
 */

// ======================================================================
// CONFIG - edit these for your library
// ======================================================================

// Display name. Used as the parent Drive folder name. Customize for your campus.
const PROJECT_NAME = 'Book Recommendation Gallery';

// Name of the logging spreadsheet.
const SHEET_NAME = 'Book Recommendations Log';

// Genres shown in the dropdown. Files are stored in subfolders matching
// these names. Add, rename, or remove freely - just keep the same list
// in submit.html, board.html, and admin.html.
const ALLOWED_CATEGORIES = [
  'Realistic Fiction',
  'Fantasy & Sci-Fi',
  'Mystery & Adventure',
  'Graphic Novel',
  'Nonfiction',
  'Biography & Memoir'
];

// Grade levels shown in the dropdown. The student's grade, not the
// recommended-for grade. Edit if your campus uses different labels.
const ALLOWED_GRADES = [
  'Pre-K', 'K', '1', '2', '3', '4', '5',
  '6', '7', '8', '9', '10', '11', '12',
  'Staff'
];

// Limits
const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;   // 25 MB
const MAX_TEXT_INLINE_BYTES = 50 * 1024;
const MAX_REFLECTION_CHARS = 500;
const MAX_TITLE_CHARS = 200;
const MAX_AUTHOR_CHARS = 120;

// ======================================================================
// (Below this line - implementation. No need to edit unless customizing.)
// ======================================================================

const SHEET_HEADERS = [
  'timestamp', 'name', 'email', 'gradeLevel',
  'bookTitle', 'bookAuthor', 'category',
  'fileName', 'mimeType', 'fileId', 'fileUrl',
  'textContent', 'reflection'
];

// Fields the admin endpoint is allowed to update.
const ADMIN_EDITABLE_FIELDS = ['bookTitle', 'bookAuthor', 'gradeLevel', 'category', 'reflection'];

// ======================================================================
// HTTP HANDLERS
// ======================================================================

function doGet(e) {
  try {
    const action = e && e.parameter && e.parameter.action;
    if (action === 'ping') {
      return jsonResponse({
        ok: true,
        project: PROJECT_NAME,
        categories: ALLOWED_CATEGORIES,
        grades: ALLOWED_GRADES,
        passcodeSet: !!PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE'),
        time: new Date().toISOString()
      });
    }
    const sheet = getOrCreateSheet();
    const submissions = readSheet(sheet);
    const filterCategory = e && e.parameter && e.parameter.category;
    let list = submissions.filter(function (s) { return s.fileId; });
    if (filterCategory) {
      list = list.filter(function (s) { return s.category === filterCategory; });
    }
    // Strip email from public response
    list = list.map(function (s) {
      const copy = {};
      Object.keys(s).forEach(function (k) {
        if (k !== 'email') copy[k] = s[k];
      });
      return copy;
    });
    list.reverse(); // newest first
    return jsonResponse({ submissions: list });
  } catch (err) {
    return jsonResponse({ error: String(err && err.message ? err.message : err) });
  }
}

function doPost(e) {
  const p = (e && e.parameter) || {};
  const action = String(p.action || 'submit');
  try {
    if (action === 'delete') return adminDelete(p);
    if (action === 'updateReflection') return adminUpdateReflection(p);
    if (action === 'updateEntry') return adminUpdateEntry(p);
    if (action === 'adminList') return adminList(p);
    return submitNew(p);
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

// ======================================================================
// PUBLIC: NEW SUBMISSION
// ======================================================================

function submitNew(p) {
  const name = String(p.name || '').trim();
  const email = String(p.email || '').trim();
  const gradeLevel = String(p.gradeLevel || '').trim();
  const bookTitle = String(p.bookTitle || '').trim();
  const bookAuthor = String(p.bookAuthor || '').trim();
  const category = String(p.category || '').trim();
  const fileName = String(p.fileName || 'upload').trim();
  const mimeType = String(p.mimeType || 'application/octet-stream').trim();
  let reflection = String(p.reflection || '').trim();
  let fileData = String(p.fileData || '');

  if (!name) return jsonResponse({ ok: false, error: 'Your name is required.' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return jsonResponse({ ok: false, error: 'A valid school email is required.' });
  }
  if (!bookTitle) return jsonResponse({ ok: false, error: 'Book title is required.' });
  if (bookTitle.length > MAX_TITLE_CHARS) {
    return jsonResponse({ ok: false, error: 'Book title is too long.' });
  }
  if (!bookAuthor) return jsonResponse({ ok: false, error: 'Author is required.' });
  if (bookAuthor.length > MAX_AUTHOR_CHARS) {
    return jsonResponse({ ok: false, error: 'Author name is too long.' });
  }
  if (gradeLevel && ALLOWED_GRADES.indexOf(gradeLevel) === -1) {
    return jsonResponse({ ok: false, error: 'Please choose a grade from the list.' });
  }
  if (ALLOWED_CATEGORIES.indexOf(category) === -1) {
    return jsonResponse({ ok: false, error: 'Please choose a genre from the list.' });
  }
  if (!fileData) return jsonResponse({ ok: false, error: 'Please add a cover image or photo.' });
  if (reflection.length > MAX_REFLECTION_CHARS) {
    reflection = reflection.slice(0, MAX_REFLECTION_CHARS);
  }

  if (fileData.indexOf(',') !== -1 && fileData.indexOf('base64') !== -1) {
    fileData = fileData.split(',')[1];
  }
  const bytes = Utilities.base64Decode(fileData);
  if (bytes.length === 0) return jsonResponse({ ok: false, error: 'The cover file appears to be empty.' });
  if (bytes.length > MAX_FILE_SIZE_BYTES) {
    return jsonResponse({ ok: false, error: 'The cover file is larger than 25 MB.' });
  }

  const blob = Utilities.newBlob(bytes, mimeType, fileName);
  const folder = getOrCreateCategoryFolder(category);
  const ts = new Date();
  const safeName = ts.getTime() + '__' + sanitize(bookTitle) + '__' + sanitize(fileName);
  const file = folder.createFile(blob.setName(safeName));

  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (sharingErr) {
    try {
      file.setSharing(DriveApp.Access.DOMAIN_WITH_LINK, DriveApp.Permission.VIEW);
    } catch (e2) { /* leave default */ }
  }

  let textContent = '';
  if ((mimeType.indexOf('text/') === 0 || mimeType === 'application/json') &&
      bytes.length < MAX_TEXT_INLINE_BYTES) {
    try { textContent = blob.getDataAsString(); } catch (txtErr) { textContent = ''; }
  }

  const sheet = getOrCreateSheet();
  appendSubmission(sheet, {
    timestamp: ts.toISOString(),
    name: name,
    email: email,
    gradeLevel: gradeLevel,
    bookTitle: bookTitle,
    bookAuthor: bookAuthor,
    category: category,
    fileName: fileName,
    mimeType: mimeType,
    fileId: file.getId(),
    fileUrl: file.getUrl(),
    textContent: textContent,
    reflection: reflection
  });

  return jsonResponse({ ok: true, fileId: file.getId(), fileUrl: file.getUrl() });
}

// ======================================================================
// ADMIN ENDPOINTS (passcode-protected)
// ======================================================================

function adminList(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });
  const sheet = getOrCreateSheet();
  const submissions = readSheet(sheet)
    .filter(function (s) { return s.fileId; })
    .reverse();
  return jsonResponse({ ok: true, submissions: submissions });
}

function adminDelete(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });
  const fileId = String(p.fileId || '').trim();
  if (!fileId) return jsonResponse({ ok: false, error: 'Missing fileId.' });

  const sheet = getOrCreateSheet();
  const rowIndex = findRowByFileId(sheet, fileId);
  if (rowIndex === -1) return jsonResponse({ ok: false, error: 'Recommendation not found in log.' });

  let driveError = null;
  try {
    const file = DriveApp.getFileById(fileId);
    file.setTrashed(true);
  } catch (err) {
    driveError = String(err);
  }

  sheet.deleteRow(rowIndex);
  return jsonResponse({ ok: true, driveError: driveError });
}

// Backward-compatible single-field update (reflection only).
function adminUpdateReflection(p) {
  return adminUpdateEntry({
    action: 'updateEntry',
    passcode: p.passcode,
    fileId: p.fileId,
    reflection: p.reflection
  });
}

// Generic entry editor. Accepts any of ADMIN_EDITABLE_FIELDS in p.
function adminUpdateEntry(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });
  const fileId = String(p.fileId || '').trim();
  if (!fileId) return jsonResponse({ ok: false, error: 'Missing fileId.' });

  const sheet = getOrCreateSheet();
  const rowIndex = findRowByFileId(sheet, fileId);
  if (rowIndex === -1) return jsonResponse({ ok: false, error: 'Recommendation not found.' });

  const headers = getHeaders(sheet);
  const updates = {};
  ADMIN_EDITABLE_FIELDS.forEach(function (field) {
    if (p.hasOwnProperty(field)) {
      let value = String(p[field] || '');
      if (field === 'reflection' && value.length > MAX_REFLECTION_CHARS) {
        value = value.slice(0, MAX_REFLECTION_CHARS);
      }
      if (field === 'bookTitle' && value.length > MAX_TITLE_CHARS) {
        value = value.slice(0, MAX_TITLE_CHARS);
      }
      if (field === 'bookAuthor' && value.length > MAX_AUTHOR_CHARS) {
        value = value.slice(0, MAX_AUTHOR_CHARS);
      }
      if (field === 'category' && value && ALLOWED_CATEGORIES.indexOf(value) === -1) {
        return; // ignore invalid category silently
      }
      if (field === 'gradeLevel' && value && ALLOWED_GRADES.indexOf(value) === -1) {
        return; // ignore invalid grade silently
      }
      updates[field] = value;
    }
  });

  Object.keys(updates).forEach(function (field) {
    const colIndex = headers.indexOf(field);
    if (colIndex !== -1) {
      sheet.getRange(rowIndex, colIndex + 1).setValue(updates[field]);
    }
  });

  return jsonResponse({ ok: true, updated: Object.keys(updates) });
}

// ======================================================================
// AUTH
// ======================================================================

function checkAdminAuth(p) {
  const stored = PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE') || '';
  if (!stored) {
    return 'Admin passcode not configured. Set ADMIN_PASSCODE in Script Properties.';
  }
  const provided = String((p && p.passcode) || '');
  if (provided !== stored) return 'Invalid passcode.';
  return null;
}

// ======================================================================
// SHEET HELPERS
// ======================================================================

function getOrCreateSheet() {
  const props = PropertiesService.getScriptProperties();
  let sheetId = props.getProperty('SHEET_ID');
  let ss = null;
  if (sheetId) {
    try { ss = SpreadsheetApp.openById(sheetId); }
    catch (err) { sheetId = null; }
  }
  if (!ss) {
    ss = SpreadsheetApp.create(SHEET_NAME);
    props.setProperty('SHEET_ID', ss.getId());
    const sheet = ss.getSheets()[0];
    sheet.appendRow(SHEET_HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, SHEET_HEADERS.length).setFontWeight('bold');
    return sheet;
  }
  // Migrate schema if needed
  const sheet = ss.getSheets()[0];
  const lastCol = Math.max(1, sheet.getLastColumn());
  const existingHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  SHEET_HEADERS.forEach(function (h) {
    if (existingHeaders.indexOf(h) === -1) {
      const newCol = sheet.getLastColumn() + 1;
      sheet.getRange(1, newCol).setValue(h).setFontWeight('bold');
    }
  });
  return sheet;
}

function getHeaders(sheet) {
  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) return [];
  return sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
}

function readSheet(sheet) {
  const range = sheet.getDataRange();
  const values = range.getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).map(function (row) {
    const obj = {};
    headers.forEach(function (h, i) { obj[h] = row[i]; });
    return obj;
  });
}

function appendSubmission(sheet, dataObj) {
  const headers = getHeaders(sheet);
  const row = headers.map(function (h) {
    return dataObj.hasOwnProperty(h) && dataObj[h] != null ? dataObj[h] : '';
  });
  sheet.appendRow(row);
}

function findRowByFileId(sheet, fileId) {
  const headers = getHeaders(sheet);
  const fileIdCol = headers.indexOf('fileId');
  if (fileIdCol === -1) return -1;
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  const ids = sheet.getRange(2, fileIdCol + 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(fileId)) return i + 2;
  }
  return -1;
}

function getOrCreateCategoryFolder(categoryName) {
  const props = PropertiesService.getScriptProperties();
  let parentId = props.getProperty('PARENT_FOLDER_ID');
  let parent = null;
  if (parentId) {
    try { parent = DriveApp.getFolderById(parentId); }
    catch (err) { parentId = null; }
  }
  if (!parent) {
    parent = DriveApp.createFolder(PROJECT_NAME);
    props.setProperty('PARENT_FOLDER_ID', parent.getId());
  }
  const existing = parent.getFoldersByName(categoryName);
  if (existing.hasNext()) return existing.next();
  return parent.createFolder(categoryName);
}

// ======================================================================
// UTILITIES
// ======================================================================

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sanitize(s) {
  return String(s).replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 60);
}

// ======================================================================
// One-time setup verification (run from the editor)
// ======================================================================

function setupNow() {
  const sheet = getOrCreateSheet();
  ALLOWED_CATEGORIES.forEach(function (c) { getOrCreateCategoryFolder(c); });
  const passcodeSet = !!PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE');
  Logger.log('Sheet URL: ' + sheet.getParent().getUrl());
  Logger.log('Genre folders verified.');
  Logger.log('Admin passcode set: ' + (passcodeSet ? 'YES' : 'NO - add ADMIN_PASSCODE in Script Properties'));
}
